# TikoWiko Bakery 🥐

Prototype de jeu de gestion (tycoon/idle) autour d'une boulangerie tenue par TikoWiko, un panda roux. Deux versions sont incluses dans ce dépôt.

## Fichiers

- **`tiko-wiko-diorama-3d.html`** — version 3D (Three.js), style diorama miniature : four à briques, personnages "meeple", boucle de production complète (pâte → cuisson → vente), employés avec IA, boutique, finances, sons, sauvegarde JSON.
- **`tiko-wiko-bakery.html`** — version 2D (Canvas), style tycoon vu du dessus, plus légère.

Aucune dépendance à installer : tout est en JavaScript vanilla dans un seul fichier HTML chacun. La version 3D charge Three.js depuis un CDN (jsdelivr) via `importmap`.

## Lancer le jeu

### Option recommandée : GitHub Pages
1. Pousse ce dépôt sur GitHub.
2. Dans **Settings → Pages**, active GitHub Pages sur la branche `main` (dossier racine).
3. Ouvre l'URL fournie (`https://<utilisateur>.github.io/<repo>/tiko-wiko-diorama-3d.html`).

### En local
La version 3D utilise des `<script type="module">` avec `importmap` : la plupart des navigateurs **bloquent les modules ES en ouvrant le fichier directement** (`file://`). Il faut donc servir le dossier via un petit serveur local, par exemple :

```bash
# Python
python3 -m http.server 8000
# puis ouvrir http://localhost:8000/tiko-wiko-diorama-3d.html
```

ou avec l'extension VS Code "Live Server". La version 2D (`tiko-wiko-bakery.html`) fonctionne en revanche directement en double-clic, sans serveur.

## Sauvegarde (version 3D)

Pas de `localStorage` (bloqué dans certains environnements sandboxés). La sauvegarde se fait :
- automatiquement en mémoire tant que l'onglet reste ouvert ;
- manuellement via le bouton **"Télécharger la sauvegarde"** (panneau Finances), qui génère un fichier `.json` à recharger plus tard avec **"Charger une sauvegarde"**.

Pour activer un vrai `localStorage` une fois hébergé (GitHub Pages, etc.), voir le commentaire au-dessus de `serializeState()` dans le fichier — il suffit de remplacer `exportSave`/`importSave` par `localStorage.setItem(...)` / `localStorage.getItem(...)`.

## État du projet

Prototype fonctionnel et testé (production, ventes, IA employés, boutique, sauvegarde), mais encore simplifié sur certains points :
- un seul pétrin partagé par tous les boulangers ;
- le pain visible sur les comptoirs est décoratif, le stock réel est suivi numériquement ;
- pas d'assets audio/image externes (sons générés en direct via WebAudio).
